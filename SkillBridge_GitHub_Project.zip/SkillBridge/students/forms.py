from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import StudentProfile

class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2")

class ProfileForm(forms.ModelForm):
    class Meta:
        model = StudentProfile
        fields = ("full_name", "course", "skills", "resume_link")
        widgets = {
            "skills": forms.TextInput(attrs={"placeholder": "Python, Django, HTML, SQL"}),
            "resume_link": forms.URLInput(attrs={"placeholder": "https://..."}),
        }
