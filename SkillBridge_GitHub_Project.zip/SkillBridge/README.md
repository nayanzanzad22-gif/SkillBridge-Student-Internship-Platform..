# SkillBridge — Student Skills & Internship Platform

SkillBridge is a Django web application starter project that helps students maintain a skills profile, browse internship opportunities, and track applications. It includes rule-based skill matching (no external AI API required).

## Features
- Student registration and login
- Student dashboard and editable skills profile
- Browse and search internships
- Rule-based skill match percentage
- Apply to internships and track application status
- Django admin panel for managing internships and applications
- Responsive interface

## Tech stack
- Python 3.10+
- Django 5
- SQLite
- HTML, CSS

## Run locally
1. Install Python 3.10 or newer.
2. Extract this ZIP and open a terminal in the `SkillBridge` folder.
3. Create and activate a virtual environment (optional but recommended):
   - Windows: `python -m venv .venv` then `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. Install dependencies:
   `pip install -r requirements.txt`
5. Create the database tables:
   `python manage.py migrate`
6. Create an admin account:
   `python manage.py createsuperuser`
7. Start the development server:
   `python manage.py runserver`
8. Visit `http://127.0.0.1:8000/`

## Add internship listings
Log in to `/admin/` using your superuser account, then add internship listings. Required skills can be entered as comma-separated values, e.g. `Python, Django, SQL`.

## Publish to GitHub
1. Create a new empty repository on GitHub named `SkillBridge`.
2. In this project folder, run:
   ```bash
   git init
   git add .
   git commit -m "Initial SkillBridge project"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/SkillBridge.git
   git push -u origin main
   ```
3. Replace `YOUR-USERNAME` with your GitHub username.

## Notes
- This is a local development starter. Before deploying publicly, configure production settings, a secure secret key, HTTPS, allowed hosts, and a production database.
- Do not commit passwords, secret keys, or the local `db.sqlite3` file.
