from django.conf import settings
from django.db import models

class StudentProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    full_name = models.CharField(max_length=120, blank=True)
    course = models.CharField(max_length=120, blank=True)
    skills = models.CharField(
        max_length=500, blank=True,
        help_text="Enter comma-separated skills, e.g. Python, HTML, SQL"
    )
    resume_link = models.URLField(blank=True)

    def skill_list(self):
        return [s.strip().lower() for s in self.skills.split(",") if s.strip()]

    def __str__(self):
        return self.full_name or self.user.username
