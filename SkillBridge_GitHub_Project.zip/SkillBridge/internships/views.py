from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from .models import Internship, Application

def internship_list(request):
    query = request.GET.get("q", "").strip()
    internships = Internship.objects.filter(is_active=True)
    if query:
        internships = internships.filter(
            Q(title__icontains=query) |
            Q(company__icontains=query) |
            Q(location__icontains=query) |
            Q(required_skills__icontains=query)
        )
    return render(request, "internships.html", {"internships": internships, "query": query})

@login_required
def apply(request, internship_id):
    if request.method != "POST":
        return redirect("internship_list")
    internship = get_object_or_404(Internship, id=internship_id, is_active=True)
    try:
        Application.objects.create(student=request.user, internship=internship)
        messages.success(request, f"Application submitted for {internship.title}.")
    except IntegrityError:
        messages.info(request, "You have already applied to this internship.")
    return redirect("dashboard")
