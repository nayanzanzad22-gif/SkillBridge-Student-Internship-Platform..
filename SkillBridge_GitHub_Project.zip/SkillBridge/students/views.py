from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from internships.models import Internship, Application
from .forms import RegisterForm, ProfileForm
from .models import StudentProfile

def home(request):
    internships = Internship.objects.filter(is_active=True)[:3]
    return render(request, "home.html", {"internships": internships})

def register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            StudentProfile.objects.get_or_create(user=user)
            login(request, user)
            messages.success(request, "Welcome to SkillBridge! Complete your profile.")
            return redirect("dashboard")
    else:
        form = RegisterForm()
    return render(request, "form_page.html", {"form": form, "title": "Create your account"})

@login_required
def dashboard(request):
    profile, _ = StudentProfile.objects.get_or_create(user=request.user)
    applications = Application.objects.filter(student=request.user).select_related("internship")
    recommendations = []
    student_skills = set(profile.skill_list())
    for internship in Internship.objects.filter(is_active=True):
        required = {s.strip().lower() for s in internship.required_skills.split(",") if s.strip()}
        match = round(100 * len(student_skills & required) / len(required)) if required else 0
        recommendations.append({"internship": internship, "match": match})
    recommendations.sort(key=lambda item: item["match"], reverse=True)
    return render(request, "dashboard.html", {
        "profile": profile,
        "applications": applications,
        "recommendations": recommendations[:5],
    })

@login_required
def edit_profile(request):
    profile, _ = StudentProfile.objects.get_or_create(user=request.user)
    if request.method == "POST":
        form = ProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated.")
            return redirect("dashboard")
    else:
        form = ProfileForm(instance=profile)
    return render(request, "form_page.html", {"form": form, "title": "Edit your profile"})
