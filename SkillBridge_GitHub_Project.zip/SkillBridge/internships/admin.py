from django.contrib import admin
from .models import Internship, Application

@admin.register(Internship)
class InternshipAdmin(admin.ModelAdmin):
    list_display = ("title", "company", "location", "is_active", "application_deadline")
    list_filter = ("is_active", "location")
    search_fields = ("title", "company", "required_skills")

@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ("student", "internship", "status", "applied_at")
    list_filter = ("status",)
    search_fields = ("student__username", "internship__title")
