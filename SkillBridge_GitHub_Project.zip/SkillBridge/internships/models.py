from django.conf import settings
from django.db import models

class Internship(models.Model):
    title = models.CharField(max_length=160)
    company = models.CharField(max_length=160)
    location = models.CharField(max_length=120, default="Remote")
    description = models.TextField()
    required_skills = models.CharField(max_length=500, blank=True)
    application_deadline = models.DateField(null=True, blank=True)
    application_url = models.URLField(blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.title} — {self.company}"

class Application(models.Model):
    STATUS_CHOICES = [
        ("submitted", "Submitted"),
        ("reviewing", "Under review"),
        ("shortlisted", "Shortlisted"),
        ("rejected", "Not selected"),
    ]
    student = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    internship = models.ForeignKey(Internship, on_delete=models.CASCADE, related_name="applications")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="submitted")
    applied_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["student", "internship"], name="unique_student_internship")
        ]
        ordering = ["-applied_at"]

    def __str__(self):
        return f"{self.student.username} — {self.internship.title}"
